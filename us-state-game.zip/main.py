import turtle
import pandas

screen = turtle.Screen()
screen.title("U.S. States Game")
screen.bgpic("blank_states_img.gif")
writer = turtle.Turtle()
writer.hideturtle()
writer.penup()

data = pandas.read_csv("50_states.csv")
correct_answers = []
all_states = data.state.to_list()
to_learn = all_states

while len(correct_answers) != 50:
    answer_state = screen.textinput(title=f"{len(correct_answers)}/50 States Correct",
                                    prompt="What's another state's name?").title()
    if answer_state == "Exit":
        for state in correct_answers:
            if state in all_states:
                to_learn.remove(state)
        new_data = pandas.DataFrame(to_learn)
        new_data.to_csv("states_to_learn.csv")
        break
    if answer_state in all_states and answer_state not in correct_answers:
        correct_answers.append(answer_state)
        selected_row = data[data.state == answer_state]
        writer.goto(int(selected_row.x), int(selected_row.y))
        writer.write(answer_state)

